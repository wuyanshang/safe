package com.example.sensitivedetection.workflow;

import com.example.sensitivedetection.model.FieldInput;
import com.example.sensitivedetection.model.FieldResult;
import com.example.sensitivedetection.rule.QualityRule;
import com.example.sensitivedetection.sensitive.KeywordMatcher;
import com.example.sensitivedetection.sensitive.LlmSensitiveDetector;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Component
public class DetectionWorkflow {

    private final List<QualityRule> qualityRules;
    private final KeywordMatcher keywordMatcher;
    private final LlmSensitiveDetector llmDetector;

    public DetectionWorkflow(List<QualityRule> qualityRules,
                             KeywordMatcher keywordMatcher,
                             LlmSensitiveDetector llmDetector) {
        this.qualityRules = qualityRules;
        this.keywordMatcher = keywordMatcher;
        this.llmDetector = llmDetector;
    }

    public List<FieldResult> execute(List<FieldInput> inputs) {
        String batchNo = generateBatchNo();
        log.info("========== 开始检测, 批次号: {}, 字段总数: {} ==========", batchNo, inputs.size());

        // 构建结果列表
        List<FieldResult> results = inputs.stream()
                .map(input -> FieldResult.from(input, batchNo))
                .collect(Collectors.toList());

        // 步骤1：质检规则
        log.info("步骤1: 执行质检规则 (A000001~A000004)");
        for (QualityRule rule : qualityRules) {
            rule.check(results);
            long count = results.stream()
                    .filter(r -> r.getQualityRuleList().stream().anyMatch(s -> s.startsWith(rule.getRuleCode())))
                    .count();
            log.info("  {} - {} : 触发 {} 条", rule.getRuleCode(), rule.getRuleDesc(), count);
        }
        // 计算质检结果
        results.forEach(FieldResult::computeQualityResult);
        long intercepted = results.stream().filter(r -> "拦截".equals(r.getQualityResult())).count();
        log.info("  质检完成: 拦截 {} 条, 通过 {} 条", intercepted, results.size() - intercepted);

        // 步骤2：关键词匹配
        log.info("步骤2: 执行关键词匹配");
        for (FieldResult result : results) {
            keywordMatcher.match(result);
        }
        long kwSensitive = results.stream().filter(r -> "关键词".equals(r.getSensitiveSource())).count();
        long kwExcluded = results.stream().filter(r -> "关键词排除".equals(r.getSensitiveSource())).count();
        long kwUndecided = results.stream().filter(r -> r.getSensitiveSource() == null).count();
        log.info("  关键词匹配完成: 敏感 {} 条, 排除 {} 条, 未决 {} 条", kwSensitive, kwExcluded, kwUndecided);

        // 步骤3：LLM 判断（只处理关键词未决的字段）
        List<FieldResult> undecided = results.stream()
                .filter(r -> r.getSensitiveSource() == null)
                .collect(Collectors.toList());
        log.info("步骤3: LLM 敏感识别, 待处理 {} 条", undecided.size());
        int processed = 0;
        for (FieldResult result : undecided) {
            llmDetector.detect(result);
            processed++;
            if (processed % 50 == 0) {
                log.info("  LLM 已处理 {}/{}", processed, undecided.size());
            }
        }
        long llmSensitive = undecided.stream().filter(r -> "是".equals(r.getIsSuspectedSensitive())).count();
        log.info("  LLM 处理完成: 疑似敏感 {} 条, 非敏感 {} 条",
                llmSensitive, undecided.size() - llmSensitive);

        // 步骤4：汇总
        long totalSensitive = results.stream().filter(r -> "是".equals(r.getIsSuspectedSensitive())).count();
        long totalNonSensitive = results.stream().filter(r -> "否".equals(r.getIsSuspectedSensitive())).count();
        long totalUncertain = results.stream().filter(r -> "不确定".equals(r.getIsSuspectedSensitive())).count();
        log.info("========== 检测完成 ==========");
        log.info("  总计: {} 条", results.size());
        log.info("  质检拦截: {} 条", intercepted);
        log.info("  疑似敏感: {} 条, 非敏感: {} 条, 不确定: {} 条", totalSensitive, totalNonSensitive, totalUncertain);

        return results;
    }

    private String generateBatchNo() {
        return LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"));
    }
}
