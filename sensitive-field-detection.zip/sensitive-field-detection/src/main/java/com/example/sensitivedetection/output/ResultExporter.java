package com.example.sensitivedetection.output;

import com.example.sensitivedetection.model.FieldResult;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Component;

import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

@Slf4j
@Component
public class ResultExporter {

    private static final String[] HEADERS = {
            "batch_no", "system_cn", "system_en", "table_cn", "table_en",
            "field_cn", "field_en", "quality_rules", "quality_result",
            "is_suspected_sensitive", "catalog_node", "sensitive_reason", "sensitive_source"
    };

    public void exportToExcel(List<FieldResult> results, String outputPath) throws IOException {
        // 确保输出目录存在
        Path path = Paths.get(outputPath);
        if (path.getParent() != null) {
            Files.createDirectories(path.getParent());
        }

        try (Workbook workbook = new XSSFWorkbook()) {
            Sheet sheet = workbook.createSheet("检测结果");

            // 创建表头样式
            CellStyle headerStyle = workbook.createCellStyle();
            Font headerFont = workbook.createFont();
            headerFont.setBold(true);
            headerStyle.setFont(headerFont);
            headerStyle.setFillForegroundColor(IndexedColors.LIGHT_BLUE.getIndex());
            headerStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);

            // 写表头
            Row headerRow = sheet.createRow(0);
            for (int i = 0; i < HEADERS.length; i++) {
                Cell cell = headerRow.createCell(i);
                cell.setCellValue(HEADERS[i]);
                cell.setCellStyle(headerStyle);
            }

            // 创建拦截行样式（红色背景）
            CellStyle interceptStyle = workbook.createCellStyle();
            interceptStyle.setFillForegroundColor(IndexedColors.ROSE.getIndex());
            interceptStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);

            // 创建疑似敏感行样式（黄色背景）
            CellStyle sensitiveStyle = workbook.createCellStyle();
            sensitiveStyle.setFillForegroundColor(IndexedColors.LIGHT_YELLOW.getIndex());
            sensitiveStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);

            // 写数据行
            for (int i = 0; i < results.size(); i++) {
                FieldResult result = results.get(i);
                Row row = sheet.createRow(i + 1);

                row.createCell(0).setCellValue(safeStr(result.getBatchNo()));
                row.createCell(1).setCellValue(safeStr(result.getSystemCn()));
                row.createCell(2).setCellValue(safeStr(result.getSystemEn()));
                row.createCell(3).setCellValue(safeStr(result.getTableCn()));
                row.createCell(4).setCellValue(safeStr(result.getTableEn()));
                row.createCell(5).setCellValue(safeStr(result.getFieldCn()));
                row.createCell(6).setCellValue(safeStr(result.getFieldEn()));
                row.createCell(7).setCellValue(safeStr(result.getQualityRules()));
                row.createCell(8).setCellValue(safeStr(result.getQualityResult()));
                row.createCell(9).setCellValue(safeStr(result.getIsSuspectedSensitive()));
                row.createCell(10).setCellValue(safeStr(result.getCatalogNode()));
                row.createCell(11).setCellValue(safeStr(result.getSensitiveReason()));
                row.createCell(12).setCellValue(safeStr(result.getSensitiveSource()));

                // 根据结果应用行样式
                CellStyle rowStyle = null;
                if ("拦截".equals(result.getQualityResult())) {
                    rowStyle = interceptStyle;
                } else if ("是".equals(result.getIsSuspectedSensitive())) {
                    rowStyle = sensitiveStyle;
                }
                if (rowStyle != null) {
                    for (int j = 0; j < HEADERS.length; j++) {
                        row.getCell(j).setCellStyle(rowStyle);
                    }
                }
            }

            // 自动列宽
            for (int i = 0; i < HEADERS.length; i++) {
                sheet.autoSizeColumn(i);
            }

            // 写入文件
            try (FileOutputStream fos = new FileOutputStream(outputPath)) {
                workbook.write(fos);
            }
        }

        log.info("结果导出完成: {}, 共 {} 条记录", outputPath, results.size());
    }

    private String safeStr(String s) {
        return s == null ? "" : s;
    }
}
