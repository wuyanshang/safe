package com.example.sensitivedetection.runner;

import com.example.sensitivedetection.config.DetectionProperties;
import com.example.sensitivedetection.model.FieldInput;
import com.example.sensitivedetection.model.FieldResult;
import com.example.sensitivedetection.output.ResultExporter;
import com.example.sensitivedetection.workflow.DetectionWorkflow;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import org.apache.poi.ss.usermodel.*;

import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.List;

@Slf4j
@Component
public class DetectionRunner implements CommandLineRunner {

    private final DetectionWorkflow workflow;
    private final ResultExporter exporter;
    private final DetectionProperties properties;

    public DetectionRunner(DetectionWorkflow workflow,
                           ResultExporter exporter,
                           DetectionProperties properties) {
        this.workflow = workflow;
        this.exporter = exporter;
        this.properties = properties;
    }

    @Override
    public void run(String... args) throws Exception {
        String inputFile = properties.getInputFile();
        String outputFile = properties.getOutputFile();

        log.info("读取输入文件: {}", inputFile);
        List<FieldInput> inputs = readExcel(inputFile);
        log.info("读取到 {} 条字段记录", inputs.size());

        if (inputs.isEmpty()) {
            log.warn("输入数据为空，跳过检测");
            return;
        }

        List<FieldResult> results = workflow.execute(inputs);

        exporter.exportToExcel(results, outputFile);
        log.info("检测完成，结果已导出到: {}", outputFile);
    }

    /**
     * 读取 Excel 文件（.xlsx / .xls）
     * 表头行：system_cn, system_en, table_cn, table_en, field_cn, field_en
     * 按列顺序读取，跳过第一行表头
     */
    private List<FieldInput> readExcel(String filePath) throws Exception {
        List<FieldInput> inputs = new ArrayList<>();
        try (FileInputStream fis = new FileInputStream(filePath);
             Workbook workbook = WorkbookFactory.create(fis)) {
            Sheet sheet = workbook.getSheetAt(0);
            for (int i = 1; i <= sheet.getLastRowNum(); i++) {
                Row row = sheet.getRow(i);
                if (row == null) continue;

                FieldInput input = new FieldInput();
                input.setSystemEn(getCellValue(row, 0));
                input.setSystemCn(getCellValue(row, 1));
                input.setTableEn(getCellValue(row, 2));
                input.setTableCn(getCellValue(row, 3));
                input.setFieldEn(getCellValue(row, 4));
                input.setFieldCn(getCellValue(row, 5));
                inputs.add(input);
            }
        }
        return inputs;
    }

    private String getCellValue(Row row, int colIndex) {
        Cell cell = row.getCell(colIndex);
        if (cell == null) return "";
        cell.setCellType(CellType.STRING);
        String value = cell.getStringCellValue();
        return value == null ? "" : value.trim();
    }
}
